<?php

if (!defined('ABSPATH')) {
    exit;
}

class QuoteBuilder_Storefront {
    private static $applies_cache = [];

    public static function init() {
        add_action('wp_enqueue_scripts', [self::class, 'assets']);
        add_filter('woocommerce_get_price_html', [self::class, 'price_html'], 20, 2);
        add_filter('woocommerce_sale_flash', [self::class, 'sale_flash'], 20, 3);
        add_filter('woocommerce_order_button_html', [self::class, 'order_button']);
        add_filter('woocommerce_loop_add_to_cart_link', [self::class, 'loop_button'], 20, 2);
        add_action('woocommerce_after_add_to_cart_button', [self::class, 'product_button_inline']);
        add_action('woocommerce_after_add_to_cart_form', [self::class, 'product_button_below']);
        add_action('woocommerce_proceed_to_checkout', [self::class, 'cart_button'], 20);
        add_action('woocommerce_review_order_before_submit', [self::class, 'checkout_button']);
        add_action('woocommerce_after_single_product_summary', ['QuoteBuilder_Complements', 'product_page'], 12);
        add_filter('render_block', [self::class, 'render_block'], 20, 2);
        add_action('wp_footer', [self::class, 'drawer']);
        add_filter('body_class', [self::class, 'body_class']);
    }

    public static function assets() {
        if (is_admin() || wp_doing_ajax() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (!QuoteBuilder_Settings::connected()) {
            return;
        }
        wp_enqueue_style(
            'quotebuilder-storefront',
            QUOTEBUILDER_URL . 'assets/storefront.css',
            [],
            QUOTEBUILDER_VERSION
        );
        wp_enqueue_script(
            'quotebuilder-storefront',
            QUOTEBUILDER_URL . 'assets/storefront.js',
            [],
            QUOTEBUILDER_VERSION,
            true
        );
        $funnel = QuoteBuilder_Settings::funnel();
        $settings = QuoteBuilder_Settings::storefront();
        $visit = self::visit_page();
        wp_localize_script('quotebuilder-storefront', 'QuoteBuilderStore', [
            'ajax' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('quotebuilder_storefront'),
            'quoteUrl' => QuoteBuilder_Quote::page_url(),
            'count' => QuoteBuilder_Quote::count(),
            'label' => $settings['buttonLabel'],
            'afterAdd' => $settings['afterAdd'],
            'addedLabel' => $settings['addedLabel'],
            'alreadyInListLabel' => $settings['alreadyInListLabel'],
            'browseListLabel' => $settings['browseListLabel'],
            'showFloatingWhenEmpty' => $settings['showFloatingWhenEmpty'] ? 1 : 0,
            'origin' => QuoteBuilder_Settings::origin(),
            'org' => $funnel['org'],
            'funnel' => $funnel['id'],
            'pageTitle' => $visit['title'],
            'pageKind' => $visit['kind'],
        ]);
    }

    public static function visit_page() {
        if (is_404() || is_feed() || is_preview()) {
            return ['kind' => '', 'title' => ''];
        }
        $kind = 'page';
        $title = '';
        if (function_exists('is_product') && is_product()) {
            $kind = 'product';
            $product = wc_get_product(get_the_ID());
            if ($product) {
                $title = $product->get_name();
            }
        } elseif (function_exists('is_product_category') && is_product_category()) {
            $kind = 'category';
            $term = get_queried_object();
            if ($term && !empty($term->name)) {
                $title = $term->name;
            }
        } elseif (function_exists('is_shop') && is_shop()) {
            $kind = 'shop';
            $title = 'Boutique';
        } elseif (function_exists('is_cart') && is_cart()) {
            $kind = 'cart';
            $title = 'Panier';
        } elseif (function_exists('is_checkout') && is_checkout()) {
            $kind = 'checkout';
            $title = 'Commande';
        } elseif ((int) get_option('quotebuilder_quote_page_id') === (int) get_queried_object_id()) {
            $kind = 'quote';
            $title = 'Demande de devis';
        }
        return [
            'kind' => $kind,
            'title' => substr(wp_strip_all_tags((string) $title), 0, 160),
        ];
    }

    public static function body_class($classes) {
        if (!QuoteBuilder_Settings::connected()) {
            return $classes;
        }
        $settings = QuoteBuilder_Settings::storefront();
        if ($settings['hidePrices']) {
            $classes[] = 'qb-hide-prices';
        }
        if ($settings['hideAddToCart']) {
            $classes[] = 'qb-hide-cart';
        }
        if ($settings['hideCheckout']) {
            $classes[] = 'qb-hide-checkout';
        }
        if ($settings['hideSaleFlash']) {
            $classes[] = 'qb-hide-sale';
        }
        $classes[] = $settings['productButtonPosition'] === 'below' ? 'qb-atq-below' : 'qb-atq-inline';
        return $classes;
    }

    public static function applies($product = null) {
        $settings = QuoteBuilder_Settings::storefront();
        if (!QuoteBuilder_Settings::connected() || !self::audience_ok($settings)) {
            return false;
        }
        if (!$product && function_exists('wc_get_product')) {
            $product = wc_get_product(get_the_ID());
        }
        if (!$product) {
            return true;
        }
        $cache_id = (int) $product->get_id();
        if (isset(self::$applies_cache[$cache_id])) {
            return self::$applies_cache[$cache_id];
        }
        if ($product->is_in_stock()) {
            if ($settings['stockMode'] === 'oos_only') {
                return self::$applies_cache[$cache_id] = false;
            }
        } elseif ($settings['stockMode'] === 'hide_oos') {
            return self::$applies_cache[$cache_id] = false;
        }
        if ($settings['scope'] === 'all') {
            return self::$applies_cache[$cache_id] = true;
        }
        $product_id = (string) $product->get_id();
        $parent_id = $product->is_type('variation') ? (string) $product->get_parent_id() : $product_id;
        $in_products = in_array($product_id, $settings['productIds'], true) || in_array($parent_id, $settings['productIds'], true);
        $in_cats = self::in_terms($parent_id, 'product_cat', $settings['categoryIds']);
        $in_tags = self::in_terms($parent_id, 'product_tag', $settings['tagIds']);
        $listed = $in_products || $in_cats || $in_tags;
        if ($settings['scope'] === 'include') {
            return self::$applies_cache[$cache_id] = $listed;
        }
        return self::$applies_cache[$cache_id] = !$listed;
    }

    private static function audience_ok($settings) {
        if ($settings['audience'] === 'logged_in') {
            return is_user_logged_in();
        }
        if ($settings['audience'] === 'guests') {
            return !is_user_logged_in();
        }
        if ($settings['audience'] === 'roles') {
            if (!is_user_logged_in()) {
                return false;
            }
            $user = wp_get_current_user();
            return (bool) array_intersect((array) $settings['roles'], (array) $user->roles);
        }
        return true;
    }

    private static function in_terms($product_id, $taxonomy, $ids) {
        if (!$ids) {
            return false;
        }
        return has_term(array_map('intval', $ids), $taxonomy, (int) $product_id);
    }

    public static function sale_flash($html, $post, $product) {
        $settings = QuoteBuilder_Settings::storefront();
        if ($settings['hideSaleFlash'] && self::applies($product)) {
            return '';
        }
        return $html;
    }

    public static function order_button($html) {
        if (QuoteBuilder_Settings::storefront()['hideCheckout']) {
            return '';
        }
        return $html;
    }

    public static function price_html($html, $product) {
        $settings = QuoteBuilder_Settings::storefront();
        if ($settings['hidePrices'] && self::applies($product)) {
            return '<span class="qb-price-hidden">' . esc_html($settings['priceLabel']) . '</span>';
        }
        return $html;
    }

    public static function loop_button($html, $product) {
        $settings = QuoteBuilder_Settings::storefront();
        if (!$settings['showOnShop'] || !self::applies($product)) {
            return $html;
        }
        if ($settings['hideAddToCart']) {
            return self::button($product);
        }
        return $html . self::button($product);
    }

    public static function product_button_inline() {
        if (QuoteBuilder_Settings::storefront()['productButtonPosition'] === 'below') {
            return;
        }
        self::product_button();
    }

    public static function product_button_below() {
        if (QuoteBuilder_Settings::storefront()['productButtonPosition'] !== 'below') {
            return;
        }
        self::product_button();
    }

    public static function product_button() {
        global $product;
        $settings = QuoteBuilder_Settings::storefront();
        if (!$settings['showOnProduct'] || !$product || !self::applies($product)) {
            return;
        }
        echo self::button($product);
    }

    public static function render_block($html, $block) {
        $name = $block['blockName'] ?? '';
        if ($name !== 'woocommerce/product-button') {
            return $html;
        }
        $settings = QuoteBuilder_Settings::storefront();
        if (!$settings['showOnBlocks'] || !function_exists('wc_get_product')) {
            return $html;
        }
        $product = wc_get_product(get_the_ID());
        if (!$product || !self::applies($product)) {
            return $html;
        }
        $button = self::button($product);
        if ($settings['hideAddToCart']) {
            return $button;
        }
        return $html . $button;
    }

    public static function cart_button() {
        $settings = QuoteBuilder_Settings::storefront();
        if (!$settings['showOnCart']) {
            return;
        }
        echo self::request_button();
    }

    public static function checkout_button() {
        $settings = QuoteBuilder_Settings::storefront();
        if (!$settings['showOnCheckout']) {
            return;
        }
        echo self::request_button();
    }

    public static function button($product, $variant = 'add') {
        $settings = QuoteBuilder_Settings::storefront();
        $is_request = $variant === 'request';
        $style = self::color_style($settings, $is_request);
        $class = ($is_request ? $settings['requestButtonStyle'] : $settings['buttonStyle']) === 'link'
            ? 'qb-atq qb-atq-link'
            : 'qb-atq';
        if ($is_request) {
            $class .= ' qb-atq-request qb-from-cart';
        }
        $label = $is_request ? $settings['requestQuoteLabel'] : $settings['buttonLabel'];
        if ($is_request) {
            return sprintf(
                '<button type="button" class="%s" style="%s">%s</button>',
                esc_attr($class),
                $style,
                esc_html($label)
            );
        }
        return sprintf(
            '<button type="button" class="%s" style="%s" data-product="%s" data-type="%s">%s</button>',
            esc_attr($class),
            $style,
            esc_attr($product->get_id()),
            esc_attr($product->get_type()),
            esc_html($label)
        );
    }

    public static function drawer_item($item) {
        $qty = max(1, (int) ($item['qty'] ?? 1));
        $name = QuoteBuilder_Quote::product_label($item['name'] ?? '');
        $variant = QuoteBuilder_Quote::variant_text($item);
        $note = QuoteBuilder_Quote::line_note($item);
        $url = $item['url'] ?? '';
        $image = $item['image'] ?? '';
        ob_start();
        ?>
        <li class="qb-line" data-id="<?php echo esc_attr($item['id'] ?? ''); ?>" data-variation="<?php echo esc_attr($item['variation_id'] ?? ''); ?>" data-qty="<?php echo esc_attr($qty); ?>">
            <div class="qb-line-main">
                <?php if ($image) : ?>
                    <a class="qb-line-photo" href="<?php echo esc_url($url); ?>">
                        <img src="<?php echo esc_url($image); ?>" alt="">
                    </a>
                <?php endif; ?>
                <div class="qb-line-copy">
                    <a class="qb-line-name" href="<?php echo esc_url($url); ?>"><?php echo esc_html($name); ?></a>
                    <?php if ($variant !== '') : ?>
                        <p class="qb-line-variant"><?php echo esc_html($variant); ?></p>
                    <?php endif; ?>
                    <?php if ($note !== '') : ?>
                        <p class="qb-line-note"><?php echo esc_html($note); ?></p>
                    <?php endif; ?>
                    <div class="qb-stepper">
                        <button type="button" class="qb-qty-minus" aria-label="Diminuer">−</button>
                        <span class="qb-qty-value"><?php echo esc_html($qty); ?></span>
                        <button type="button" class="qb-qty-plus" aria-label="Augmenter">+</button>
                    </div>
                </div>
                <button type="button" class="qb-remove">Retirer</button>
            </div>
            <div class="qb-undo" hidden>
                <span>Retiré de la liste</span>
                <button type="button" class="qb-undo-cancel">Annuler</button>
            </div>
        </li>
        <?php
        return apply_filters('quotebuilder_drawer_item_html', ob_get_clean(), $item);
    }

    public static function drawer_body($items = null) {
        if ($items === null) {
            $items = QuoteBuilder_Quote::items();
        }
        $settings = QuoteBuilder_Settings::storefront();
        $unique = count($items);
        $qty = 0;
        foreach ($items as $item) {
            $qty += max(1, (int) ($item['qty'] ?? 1));
        }
        ob_start();
        ?>
        <header class="qb-drawer-head">
            <h2><?php echo esc_html($settings['listTitle']); ?></h2>
            <?php if ($unique) : ?>
                <p class="qb-drawer-summary"><?php echo esc_html(QuoteBuilder_Quote::tally_label($unique, $qty)); ?></p>
            <?php endif; ?>
        </header>
        <?php if (!$unique) : ?>
            <p class="qb-drawer-empty"><?php echo esc_html($settings['drawerEmpty']); ?></p>
            <a class="qb-drawer-quiet" href="<?php echo esc_url(QuoteBuilder_Quote::page_url()); ?>">Décrire mon besoin</a>
        <?php else : ?>
            <ul class="qb-drawer-items">
                <?php foreach ($items as $item) : ?>
                    <?php echo self::drawer_item($item); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php endforeach; ?>
            </ul>
            <footer class="qb-drawer-foot">
                <?php if ($settings['drawerReassure'] !== '') : ?>
                    <p class="qb-drawer-reassure"><?php echo esc_html($settings['drawerReassure']); ?></p>
                <?php endif; ?>
                <a class="qb-drawer-go" href="<?php echo esc_url(QuoteBuilder_Quote::page_url()); ?>">
                    <strong><?php echo esc_html($settings['drawerCta']); ?></strong>
                    <?php if ($settings['drawerCtaHint'] !== '') : ?>
                        <span><?php echo esc_html($settings['drawerCtaHint']); ?></span>
                    <?php endif; ?>
                </a>
            </footer>
        <?php endif; ?>
        <?php
        return apply_filters('quotebuilder_drawer_html', ob_get_clean(), $items, $settings);
    }

    public static function floating_style($floating) {
        $bg = sanitize_hex_color($floating['bg'] ?? '') ?: '#16110D';
        $color = sanitize_hex_color($floating['color'] ?? '') ?: '#FFFFFF';
        $badge = sanitize_hex_color($floating['badge'] ?? '') ?: '#E85D04';
        return '--qb-fab-bg:' . $bg . ';--qb-fab-color:' . $color . ';--qb-fab-badge:' . $badge . ';';
    }

    public static function request_button() {
        return self::button(null, 'request');
    }

    public static function color_style($settings, $request = false) {
        $map = $request
            ? [
                '--qb-btn-bg' => 'requestBg',
                '--qb-btn-bg-hover' => 'requestBgHover',
                '--qb-btn-border' => 'requestBorder',
                '--qb-btn-border-hover' => 'requestBorderHover',
                '--qb-btn-color' => 'requestColor',
                '--qb-btn-color-hover' => 'requestColorHover',
            ]
            : [
                '--qb-btn-bg' => 'buttonBg',
                '--qb-btn-bg-hover' => 'buttonBgHover',
                '--qb-btn-border' => 'buttonBorder',
                '--qb-btn-border-hover' => 'buttonBorderHover',
                '--qb-btn-color' => 'buttonColor',
                '--qb-btn-color-hover' => 'buttonColorHover',
            ];
        $parts = [];
        foreach ($map as $var => $key) {
            $parts[] = $var . ':' . esc_attr($settings[$key]);
        }
        return implode(';', $parts) . ';';
    }

    public static function drawer() {
        if (is_admin() || wp_doing_ajax() || !QuoteBuilder_Settings::connected()) {
            return;
        }
        $count = QuoteBuilder_Quote::count();
        $items = QuoteBuilder_Quote::items();
        $settings = QuoteBuilder_Settings::storefront();
        $defaults = [
            'label' => $settings['floatingLabel'],
            'position' => $settings['floatingPosition'] === 'left' ? 'left' : 'right',
            'enabled' => (bool) $settings['showFloatingButton'],
            'bg' => $settings['floatingBg'],
            'color' => $settings['floatingColor'],
            'badge' => $settings['floatingBadge'],
        ];
        $filtered = apply_filters('quotebuilder_floating_button', $defaults, $count);
        $floating = array_merge($defaults, is_array($filtered) ? $filtered : []);
        $position = ($floating['position'] ?? 'right') === 'left' ? 'left' : 'right';
        $side = $position === 'left' ? ' is-left' : '';
        $visible = $count || !empty($settings['showFloatingWhenEmpty']);
        ?>
        <div class="qb-backdrop" hidden></div>
        <aside class="qb-drawer<?php echo esc_attr($side); ?>" hidden>
            <button type="button" class="qb-drawer-close" aria-label="Fermer">×</button>
            <div data-qb-drawer-body>
                <?php echo self::drawer_body($items); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        </aside>
        <div class="qb-toast" hidden></div>
        <?php if (!empty($floating['enabled'])) : ?>
        <button type="button" class="qb-fab<?php echo esc_attr($side); ?>" data-count="<?php echo esc_attr($count); ?>" data-position="<?php echo esc_attr($position); ?>" style="<?php echo esc_attr(self::floating_style($floating)); ?>" <?php echo $visible ? '' : 'hidden'; ?>>
            <span><?php echo esc_html($count); ?></span>
            <?php echo esc_html($floating['label'] ?? 'Devis'); ?>
        </button>
        <?php endif; ?>
        <?php
    }

    public static function render_funnel($atts = []) {
        $funnel = QuoteBuilder_Settings::funnel();
        $atts = shortcode_atts([
            'org' => $funnel['org'],
            'id' => $funnel['id'],
            'height' => '720px',
            'cart' => '',
            'module' => '',
            'placeholder' => '',
            'promise' => '',
            'phone' => '',
        ], $atts, 'quotebuilder');

        if ($atts['module'] === 'quote') {
            $args = [];
            if ($atts['cart'] !== '') {
                $args['cart'] = $atts['cart'];
            }
            return self::render_quote_widget($args);
        }

        $origin = esc_url(QuoteBuilder_Settings::origin());
        if (!$atts['org'] || !$atts['id'] || !QuoteBuilder_Settings::connected()) {
            return '<p class="qb-empty">Connectez QuoteBuilder dans WordPress pour afficher le funnel et collecter les demandes.</p>';
        }
        wp_enqueue_script(
            'quotebuilder-widget',
            $origin . '/widget.js',
            [],
            null,
            true
        );

        $cart = $atts['cart'] ?: (QuoteBuilder_Quote::items() ? wp_json_encode(QuoteBuilder_Quote::cart_payload()) : '');

        $extra = '';
        if ($atts['module'] === 'capture' || $atts['module'] === 'agent') {
            $extra .= ' data-module="' . esc_attr($atts['module']) . '"';
        }
        if ($atts['placeholder'] !== '') {
            $extra .= ' data-placeholder="' . esc_attr($atts['placeholder']) . '"';
        }
        if ($atts['promise'] !== '') {
            $extra .= ' data-promise="' . esc_attr($atts['promise']) . '"';
        }
        if ($atts['phone'] !== '') {
            $extra .= ' data-phone="' . esc_attr($atts['phone']) . '"';
        }
        if ($cart) {
            $extra .= ' data-cart="' . esc_attr($cart) . '"';
        }

        return sprintf(
            '<div class="quotebuilder-embed" data-quotebuilder data-org="%s" data-id="%s" data-height="%s"%s></div>',
            esc_attr($atts['org']),
            esc_attr($atts['id']),
            esc_attr($atts['height']),
            $extra
        );
    }

    public static function render_quote_widget($atts = []) {
        $widget = QuoteBuilder_Settings::widget();
        $atts = shortcode_atts([
            'site_key' => QuoteBuilder_Settings::site_key(),
            'mode' => $widget['mode'],
            'ai' => $widget['aiRequestText'] ? '1' : '0',
            'cart' => '',
        ], $atts, 'quotebuilder_widget');

        $key = sanitize_text_field($atts['site_key']);
        if ($key === '' || strpos($key, 'qb_site_') !== 0) {
            return '<p class="qb-empty">Connectez QuoteBuilder pour afficher le widget devis. La clé publique du site est requise.</p>';
        }

        $origin = esc_url(QuoteBuilder_Settings::origin());
        wp_enqueue_script(
            'quotebuilder-widget',
            $origin . '/widget.js',
            [],
            null,
            true
        );

        $cart = $atts['cart'] ?: (QuoteBuilder_Quote::items() ? wp_json_encode(QuoteBuilder_Quote::cart_payload()) : '');
        $mode = in_array($atts['mode'], ['catalog', 'request', 'both'], true) ? $atts['mode'] : 'both';
        $ai = ($atts['ai'] === '1' || $atts['ai'] === 'true') ? '1' : '0';
        $path = (string) get_option('quotebuilder_public_submit_path', '');
        $expected = '/api/public/sites/' . rawurlencode($key) . '/quotes';
        if ($path !== $expected) {
            $path = $expected;
        }

        $extra = '';
        if ($cart) {
            $extra .= ' data-cart="' . esc_attr($cart) . '"';
        }

        return sprintf(
            '<div data-qb-widget data-site-key="%s" data-mode="%s" data-ai="%s" data-submit-path="%s"%s></div>',
            esc_attr($key),
            esc_attr($mode),
            esc_attr($ai),
            esc_attr($path),
            $extra
        );
    }
}
